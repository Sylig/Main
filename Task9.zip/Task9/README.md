HIGHER ORDER FUNCTIONS AND CALLBACKS

9.Task - Steps

1. Task

- Create a higher-order function named myFilterFunction() in a file named higherOrder.js (do not use the built-in function at all – the objective is to create a different filter function of your own).
- Your filter function should take the following two arguments:
1. An array of strings with 10 words, where at least three of the words
have six letters.
2. A callback function that returns a boolean based on whether or not a word has six letters.
-  myFilterFunction() should return a new array that contains only the words that are six letters long and no other words.

2. Task

For this Practical Task, you will need a comprehensive understanding of both the
setInterval() and the clearInterval() functions, and how they can be used.

- Follow the instructions in the callBack.js file that can be found in the task folder.
When the start button is clicked, your program should output a number to the console every 1,000 ms, starting from 1 and incrementing the output by 1 every time. 
When the stop button is clicked, your program should stop all output to the console.

Author: Simona Ligorio

