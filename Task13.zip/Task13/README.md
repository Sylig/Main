Promises, Async and Await

13.Task - Steps

1. Task
- You’re going to use promises to make an API call that gets information about a Pokémon.
- Use this link to call the API: https://pokeapi.co/api/v2/pokemon/squirtle/
- Note that you can replace the Pokémon character {squirtle} with the name of your favourite Pokémon. If you don’t know any Pokémon, you can use this website and find the one you like the most: https://www.pokemon.com/us/pokedex/
- Now print out the following about the Pokémon:
○ Their name
○ Their weight
○ Their abilities

2. Task

- Use async/await to fetch data from a URL to randomly generate cat GIFs.
- Use the following API URL to fetch a random GIF of a cat: http://thecatapi.com/api/images/get?format=src&type=gif
- Please only output the image URL in the console.

