Node.JS

15.Task - Steps

- Create a module called my_first_task.
- Initialise the module with NPM.
- Install lodash to this module.
- Create a script called remove_duplicates.js.
- Within this script, you will need to import lodash, and use the uniq
function.
- Create the following array:
[1, 2, 10, 100, 10, 2, 5, 6, 10, 1000, 7, 2, 100, 1, 5, 7, 10]
- Using lodash, print out that same array, but with all duplicates removed.
- Finally, set up your module to run the script using:
> npm run rdup
Once you are ready to have your code reviewed, delete the node_modules
folder (this folder typically contains hundreds of files which, if you're working
directly from Dropbox, has the potential to slow down Dropbox sync and,
possibly, your computer), compress your project folder, and add it to the relevant
task folder in Dropbox.

Author: Simona Ligorio