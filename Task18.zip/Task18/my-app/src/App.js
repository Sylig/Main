import BankAccount from "./components/BankAccount";
import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <BankAccount />
        
      </header>
    </div>
  );
}

export default App;
