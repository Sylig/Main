import "./App.css";
import WeatherApp from "./components/main";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <WeatherApp />

        <style>{"body { background: #74839e;}"}</style>
      </header>
    </div>
  );
}

export default App;
